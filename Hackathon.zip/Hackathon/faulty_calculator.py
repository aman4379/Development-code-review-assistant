import math

class Calculator:
    def add(self, a, b):
        return a + b

    def subtract(self, a, b):
        return a - b

    def multiply(self, a, b):
        return a * b

    def divide(self, a, b):
        return a / b

    def power(self, a, b):
        return math.pow(a, b)

    def square_root(self, a):
        return math.sqrt(a)


def main():
    calc = Calculator()

    print("=== Buggy Calculator ===")
    print("Operations: +, -, *, /, ^, sqrt, exit")

    while True:
        op = input("\nEnter operation: ")

        if op == "exit":
            print("Bye!")
            break

        num1 = float(input("Enter first number: "))

        if op != "sqrt":
            num2 = float(input("Enter second number: "))

        if op == "+":
            print("Result:", calc.add(num1, num2))
        elif op == "-":
            print("Result:", calc.subtract(num1, num2))
        elif op == "*":
            print("Result:", calc.multiply(num1, num2))
        elif op == "/":
            print("Result:", calc.divide(num1, num2))
        elif op == "^":
            print("Result:", calc.power(num1, num2))
        elif op == "sqrt":
            print("Result:", calc.square_root(num1))
        else:
            print("Invalid operation!")


if __name__ == "__main__":
    main()
