import streamlit as st
import PyPDF2
import docx
from typing import Optional
from langchain_openai import ChatOpenAI
import httpx

# ---------------- LLM CONFIG ---------------- #

client = httpx.Client(verify=False)
llm = ChatOpenAI(
    base_url="https://genailab.tcs.in",
    model="azure_ai/genailab-maas-DeepSeek-V3-0324",
    api_key="sk-v_97T-HhfUi995bTw0Quxg",
    http_client=client
)

# ---------------- APP CONFIG ---------------- #

st.set_page_config(
    page_title="Application Development Code Review Assistant",
    page_icon="🧠",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ----- Supported Extensions ----- #
TEXT_FILE_EXTENSIONS = [
    "txt", "py", "java", "js", "cpp", "c", "html", "css", "json", "xml", "sql", "csv", "md", "ts"
]
DOC_FILE_EXTENSIONS = ["pdf", "docx"]
SUPPORTED_EXTENSIONS = TEXT_FILE_EXTENSIONS + DOC_FILE_EXTENSIONS

# ---------------- CUSTOM CSS ---------------- #

CUSTOM_CSS = """
<style>
    body {
        background-color: #f4f6f9;
    }

    .main > div {
        padding-left: 5%;
        padding-right: 5%;
    }

    .header {
        font-size: 2.5rem;
        text-align: center;
        color: #333;
        margin-bottom: 0.3rem;
    }

    .subheader {
        text-align: center;
        font-size: 1.1rem;
        color: #666;
        margin-bottom: 1.5rem;
    }

    .stExpander, .feedback-box {
        background-color: #ffffff !important;
        border-radius: 8px;
        padding: 1rem;
        box-shadow: 0 2px 6px rgba(0,0,0,0.05);
        border: 1px solid #e0e0e0;
    }

    .feedback-content {
        background-color: #fdfdfd;
        padding: 1rem;
        border-left: 5px solid #3a86ff;
        font-size: 1rem;
        border-radius: 5px;
        line-height: 1.6;
        color: #333;
    }

    .stButton>button {
        width: 100%;
        background-color: #3a86ff;
        color: white;
        border: none;
        border-radius: 5px;
        padding: 0.6rem 1rem;
        font-weight: 600;
        margin-top: 1rem;
        transition: background-color 0.3s ease;
    }

    .stButton>button:hover {
        background-color: #265ecf;
        color: #fff;
    }

    .stFileUploader {
        background-color: #ffffff;
        padding: 1rem;
        border-radius: 6px;
        border: 1px solid #ccc;
        box-shadow: 0 1px 2px rgba(0,0,0,0.05);
    }

    .css-1d391kg, .css-1dp5vir, .css-1lcbmhc {
        background-color: #f9fafb !important;
        padding: 1rem;
        border-right: 1px solid #e1e4e8;
    }

    pre code {
        font-size: 0.9rem;
    }
</style>
"""

# ---------------- UTILS ---------------- #

def extract_text_from_pdf(file) -> str:
    try:
        reader = PyPDF2.PdfReader(file)
        return "\n".join(page.extract_text() or "" for page in reader.pages).strip()
    except Exception as e:
        st.error(f"❌ Error reading PDF file: {e}")
        return ""

def extract_text_from_docx(file) -> str:
    try:
        doc = docx.Document(file)
        return "\n".join(para.text for para in doc.paragraphs).strip()
    except Exception as e:
        st.error(f"❌ Error reading DOCX file: {e}")
        return ""

def extract_text_from_text_based(file) -> str:
    try:
        return file.read().decode("utf-8", errors="ignore").strip()
    except Exception as e:
        st.error(f"❌ Error reading text/code file: {e}")
        return ""

def extract_text(file, file_type: str) -> Optional[str]:
    if file_type == "pdf":
        return extract_text_from_pdf(file)
    elif file_type == "docx":
        return extract_text_from_docx(file)
    elif file_type in TEXT_FILE_EXTENSIONS:
        return extract_text_from_text_based(file)
    else:
        st.warning("⚠️ Unsupported file type.")
        return None

def call_llm_api(code: str) -> dict:
    try:
        base_prompt = (
            "You are a senior software engineer assisting with code reviews. "
            "Given a code snippet, provide the following:\n"
            "- Code quality and style feedback\n"
            "- Bug detection and improvements\n"
            "- Best practices\n"
            "- A corrected or improved version of the code\n"
            "Respond in the following format:\n"
            "[FEEDBACK]: ... \n[CORRECTED_CODE]: ```<language>\n...\n```"
        )

        if st.session_state.get('reference_doc'):
            base_prompt = (
                "Use the following standard documentation as a reference while reviewing the code:\n"
                f"{st.session_state['reference_doc']}\n\n" +
                base_prompt
            )

        response = llm.invoke([
            {"role": "system", "content": base_prompt},
            {"role": "user", "content": code}
        ])

        message = response.content
        return parse_llm_response(message)

    except Exception as e:
        st.error(f"❌ Error communicating with LLM: {e}")
        return {"feedback": "Error during LLM invocation.", "corrected_code": ""}

def parse_llm_response(message: str) -> dict:
    feedback = ""
    corrected_code = ""

    if "[FEEDBACK]:" in message and "[CORRECTED_CODE]:" in message:
        parts = message.split("[CORRECTED_CODE]:")
        feedback = parts[0].replace("[FEEDBACK]:", "").strip()
        corrected_code = parts[1].strip("` \n")
    else:
        feedback = message
    return {"feedback": feedback, "corrected_code": corrected_code}

# ---------------- UI COMPONENTS ---------------- #

def sidebar():
    st.sidebar.title("🧠 Code Review Assistant")
    st.sidebar.markdown(
        """
        Welcome!  
        Upload your source code or document  
        to get **instant AI-powered feedback**.

        ---
        **Supported file types:**  
        `.py`, `.java`, `.cpp`, `.js`, `.html`, `.css`, `.json`, `.txt`, `.pdf`, `.docx`, and more.

        ---
        ### 📚 Optional: Upload Reference Documentation
        Upload standard documentation (PDF or DOCX)

        Drag and drop file here  
        Limit 200MB per file • PDF, DOCX
        """
    )

    reference_file = st.sidebar.file_uploader(
        "Upload Reference Documentation",
        type=["pdf", "docx"],
        key="reference_doc_file"
    )
    if reference_file is not None:
        doc_file_type = reference_file.name.split(".")[-1].lower()
        doc_text = extract_text(reference_file, doc_file_type)
        st.session_state['reference_doc'] = doc_text
        st.sidebar.success("✅ Reference documentation uploaded.")
    else:
        if 'reference_doc' not in st.session_state:
            st.session_state['reference_doc'] = None

    st.sidebar.markdown("---")

    # Sync sidebar radio with session_state page for proper navigation
    default_page = st.session_state.get('page', 'upload_code').replace("_", " ").title()
    page = st.sidebar.radio("📂 Navigate", ["Upload Code", "Review Results"], index=["Upload Code", "Review Results"].index(default_page))
    st.session_state.page = page.lower().replace(" ", "_")

def upload_page():
    st.markdown("<h1 class='header'>🧠 Application Development Code Review Assistant</h1>", unsafe_allow_html=True)
    st.markdown("<p class='subheader'>Upload your code file or document to receive a detailed AI-powered code review.</p>", unsafe_allow_html=True)
    st.write("")

    col1, col2 = st.columns([3, 2])
    with col1:
        uploaded_file = st.file_uploader(
            "📁 Upload your code or document file", 
            type=SUPPORTED_EXTENSIONS, 
            help="Supported formats: " + ", ".join(SUPPORTED_EXTENSIONS)
        )

    with col2:
        st.info(
            """
            **Steps:**  
            1. Upload your file  
            2. (Optional) Upload standard documentation for better review (see sidebar)  
            3. Click 'Analyze Code'  
            4. View AI-generated report
            """
        )

    if uploaded_file:
        file_name = uploaded_file.name
        file_type = file_name.split(".")[-1].lower()

        with st.expander("📄 File Details", expanded=True):
            st.json({
                "Filename": file_name,
                "Type": uploaded_file.type,
                "Size (KB)": round(uploaded_file.size / 1024, 2)
            })

        code_text = extract_text(uploaded_file, file_type)

        if code_text:
            st.session_state['original_code'] = code_text
            st.session_state['language'] = file_type
            st.success("✅ Code extracted successfully.")

            st.markdown("---")
            analyze_btn = st.button("🔍 Analyze Code", use_container_width=True)

            if analyze_btn:
                st.session_state['page'] = 'review_results'
                st.experimental_rerun()
        else:
            st.error("❌ No extractable text found in the uploaded file.")

def review_page():
    st.markdown("<h1 class='header'>🧾 AI Code Review Report</h1>", unsafe_allow_html=True)

    code = st.session_state.get('original_code', '')
    language = st.session_state.get('language', 'text')

    if not code:
        st.warning("⚠️ No code found. Please upload a file first.")
        if st.button("🔙 Back to Upload"):
            st.session_state['page'] = 'upload_code'
            st.experimental_rerun()
        return

    with st.expander("📄 Original Code (Click to Expand/Collapse)", expanded=False):
        st.code(code, language=language)

    with st.spinner("🧠 Analyzing your code with AI... Please wait."):
        result = call_llm_api(code)

    st.markdown("---")
    st.subheader("📋 AI Feedback (Review Report)")
    st.markdown(
        f"<div class='feedback-content'>{result['feedback'].replace(chr(10), '<br>')}</div>",
        unsafe_allow_html=True
    )

    st.markdown("---")
    st.subheader("✅ AI-Corrected Code")
    st.code(result["corrected_code"], language=language)

    report_text = f"""\ 
==========================
🧾 AI CODE REVIEW REPORT
==========================

[FEEDBACK]:

{result['feedback']}

--------------------------
[CORRECTED CODE]:
--------------------------
{result['corrected_code']}
"""

    st.markdown("---")
    st.subheader("📤 Export Options")
    col1, col2, col3 = st.columns([1, 1, 1])

    with col1:
        if st.button("🔁 Upload Another File"):
            st.session_state['page'] = 'upload_code'
            st.experimental_rerun()

    with col2:
        st.download_button(
            label="💾 Download Improved Code Only",
            data=result["corrected_code"],
            file_name="corrected_code.txt",
            mime="text/plain",
            use_container_width=True
        )

    with col3:
        st.download_button(
            label="📄 Download Full Review Report",
            data=report_text,
            file_name="code_review_report.txt",
            mime="text/plain",
            use_container_width=True
        )

# ---------------- MAIN ---------------- #

def main():
    st.markdown(CUSTOM_CSS, unsafe_allow_html=True)

    if "page" not in st.session_state:
        st.session_state.page = "upload_code"

    sidebar()

    if st.session_state.page == "upload_code":
        upload_page()
    elif st.session_state.page == "review_results":
        review_page()
    else:
        st.error("Page not found. Please use the sidebar to navigate.")

if __name__ == "__main__":
    main()
