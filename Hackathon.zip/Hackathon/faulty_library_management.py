class book:
 def __init__(self, id, title, author, copies=1):
  self.id = id; self.title = title; self.author = author; self.copies = copies; self.borrowed = []

 def __str__(self): return f"{self.title}-{self.author}-{self.copies}"


class member:
 def __init__(self, mid, name): self.mid = mid; self.name = name; self.borrowed = []


class lib:
 def __init__(self): self.books = {}; self.members = {}

 def addBook(self, id, title, author, copies=1):
    if id in self.books: self.books[id].copies += copies; print("copies added")
  else: self.books[id] = book(id, title, author, copies); print("book added")

 def addMember(self, mid, name):
  if mid in self.members: print("exists")
  else: self.members[mid] = member(mid, name); print("member added")

 def borrow(self, mid, bid):
  b = self.books[bid]
  m = self.members[mid]
  if b.copies <= 0: print("not available"); return
  b.copies -= 1; b.borrowed.append(mid); m.borrowed.append(bid); print(m.name, "borrowed", b.title)

 def returnBook(self, mid, bid):
  b = self.books[bid]; m = self.members[mid]
  if bid not in m.borrowed: print("not borrowed by user"); return
  m.borrowed.remove(bid); b.borrowed.remove(mid); b.copies += 1; print("returned")

 def list(self):
  for k, v in self.books.items(): print(v.id, v.title, v.copies)


L = lib()
L.addBooks(1, "Python Crash Course", "Eric", 2)
L.addBook(2, "1984", "George Orwell", 1)
L.addMember(1, "Aman")
L.addMember(2, "Bob")

L.borrow(1, 1)
L.borrow(2, 3)
L.returnBook(1, 2)

L.list()
