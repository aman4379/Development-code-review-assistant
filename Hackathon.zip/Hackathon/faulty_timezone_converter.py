import datetime, pytz

def t(z):
 tz = pytz.timezone(z)
 x = datetime.datetime.now(tz)
 print("time in", z, "is", x)

def main():
 print("enter tz name OR quit")
 while True:
  i = input(">>> ")
  if i == "quit": break
  elif len(i) == 0: print("nothing entered")
  else:
   try: t(i)
   except: print("something wrong lol")

main()
